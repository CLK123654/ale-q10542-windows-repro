CREATE OR REPLACE VIEW randomization_balance AS
WITH counts AS (
  SELECT platform,market,
    count(*) FILTER (WHERE variant='control')::integer AS control_users,
    count(*) FILTER (WHERE variant='treatment')::integer AS treatment_users,
    count(*)::integer AS total_users
  FROM assignments GROUP BY platform,market
)
SELECT c.*,
  abs(control_users-treatment_users)::integer AS abs_delta,
  CASE
    WHEN control_users=treatment_users THEN 'balanced'
    WHEN abs(control_users-treatment_users)<=p.balance_watch_abs_delta_max THEN 'watch'
    ELSE 'investigate'
  END AS status
FROM counts c CROSS JOIN analysis_policy p;

CREATE OR REPLACE VIEW analysis_orders AS
SELECT o.order_id,o.user_id,o.paid_at,o.revenue
FROM orders o
JOIN assignments a USING(user_id)
CROSS JOIN analysis_policy p
WHERE o.paid_at>=p.analysis_start_utc AND o.paid_at<p.analysis_end_utc;

CREATE OR REPLACE VIEW cuped_user_metric AS
WITH pre AS (
  SELECT avg(m.pre_revenue)::numeric AS pre_mean
  FROM assignments a JOIN pre_period_metrics m USING(user_id)
), post AS (
  SELECT user_id,sum(revenue)::numeric AS raw_revenue
  FROM analysis_orders GROUP BY user_id
)
SELECT a.user_id,a.variant,m.pre_revenue,pre.pre_mean AS pre_mean_revenue,p.cuped_theta,
  coalesce(post.raw_revenue,0)::numeric AS raw_revenue,
  coalesce(post.raw_revenue,0)-p.cuped_theta*(m.pre_revenue-pre.pre_mean) AS adjusted_revenue
FROM assignments a
JOIN pre_period_metrics m USING(user_id)
LEFT JOIN post USING(user_id)
CROSS JOIN pre
CROSS JOIN analysis_policy p;

CREATE OR REPLACE VIEW cuped_revenue_by_variant AS
SELECT variant,count(*)::integer AS users,
  round(sum(raw_revenue),4) AS raw_revenue,
  round(avg(raw_revenue),4) AS avg_raw_revenue,
  round(sum(adjusted_revenue),4) AS cuped_revenue,
  round(avg(adjusted_revenue),4) AS avg_cuped_revenue
FROM cuped_user_metric GROUP BY variant;

CREATE OR REPLACE VIEW data_quality_flags AS
WITH p AS (SELECT * FROM analysis_policy), flags AS (
  SELECT 'pre_assignment_exposure'::text AS flag_type,count(*)::integer AS affected_rows,
    count(DISTINCT e.user_id)::integer AS affected_users
  FROM exposure_events e JOIN assignments a USING(user_id) CROSS JOIN p
  WHERE e.experiment_id=p.experiment_id AND e.exposed_at<a.assigned_at
  UNION ALL
  SELECT 'cross_experiment_exposure',count(*)::integer,count(DISTINCT e.user_id)::integer
  FROM exposure_events e CROSS JOIN p WHERE e.experiment_id<>p.experiment_id
  UNION ALL
  SELECT 'metric_outside_window',count(*)::integer,count(DISTINCT o.user_id)::integer
  FROM orders o CROSS JOIN p WHERE o.paid_at<p.analysis_start_utc OR o.paid_at>=p.analysis_end_utc
  UNION ALL
  SELECT 'unassigned_checkout_activity',count(*)::integer,count(DISTINCT x.user_id)::integer
  FROM (
    SELECT user_id FROM orders
    UNION ALL
    SELECT e.user_id FROM exposure_events e CROSS JOIN p WHERE e.experiment_id=p.experiment_id
  ) x LEFT JOIN assignments a USING(user_id)
  WHERE a.user_id IS NULL
)
SELECT f.flag_type,f.affected_rows,f.affected_users,h.handling
FROM flags f JOIN quality_handling h USING(flag_type);
