INSERT INTO assignments (user_id, platform, market, variant, assigned_at) VALUES
('buyer_aurora', 'ios', 'US', 'control', '2026-07-10 09:00:00+00'),
('buyer_birch', 'ios', 'US', 'treatment', '2026-07-10 09:01:00+00'),
('buyer_cedar', 'ios', 'US', 'control', '2026-07-10 09:02:00+00'),
('buyer_delta', 'ios', 'US', 'treatment', '2026-07-10 09:03:00+00'),
('buyer_ember', 'ios', 'JP', 'control', '2026-07-10 09:04:00+00'),
('buyer_fjord', 'ios', 'JP', 'treatment', '2026-07-10 09:05:00+00'),
('buyer_grove', 'android', 'US', 'control', '2026-07-10 09:06:00+00'),
('buyer_harbor', 'android', 'US', 'treatment', '2026-07-10 09:07:00+00'),
('buyer_indigo', 'android', 'US', 'treatment', '2026-07-10 09:08:00+00'),
('buyer_juniper', 'android', 'JP', 'control', '2026-07-10 09:09:00+00'),
('buyer_kestrel', 'android', 'JP', 'treatment', '2026-07-10 09:10:00+00'),
('buyer_lotus', 'android', 'JP', 'treatment', '2026-07-10 09:11:00+00');

INSERT INTO pre_period_metrics (user_id, pre_orders, pre_revenue) VALUES
('buyer_aurora',2,80),('buyer_birch',3,110),('buyer_cedar',2,95),('buyer_delta',3,105),
('buyer_ember',2,70),('buyer_fjord',2,90),('buyer_grove',3,130),('buyer_harbor',3,120),
('buyer_indigo',3,100),('buyer_juniper',2,60),('buyer_kestrel',2,75),('buyer_lotus',3,115);

INSERT INTO exposure_events (event_id,user_id,experiment_id,exposed_at,surface) VALUES
('evt_checkout_a','buyer_aurora','checkout_refresh_2026_07','2026-07-10 09:05:00+00','checkout'),
('evt_checkout_b','buyer_birch','checkout_refresh_2026_07','2026-07-10 09:06:00+00','checkout'),
('evt_checkout_c','buyer_delta','checkout_refresh_2026_07','2026-07-10 08:55:00+00','checkout'),
('evt_checkout_d','buyer_fjord','checkout_refresh_2026_07','2026-07-10 09:20:00+00','checkout'),
('evt_checkout_e','buyer_harbor','checkout_refresh_2026_07','2026-07-10 09:22:00+00','checkout'),
('evt_checkout_f','buyer_kestrel','checkout_refresh_2026_07','2026-07-10 09:00:00+00','checkout'),
('evt_search_archive','buyer_cedar','search_layout_2026_06','2026-07-11 11:00:00+00','search'),
('evt_unassigned_checkout','buyer_mistral','checkout_refresh_2026_07','2026-07-12 11:00:00+00','checkout');

INSERT INTO orders (order_id,user_id,paid_at,revenue) VALUES
('sale_a01','buyer_aurora','2026-07-11 10:15:00+00',120),
('sale_b02','buyer_birch','2026-07-12 11:15:00+00',180),
('sale_c03','buyer_cedar','2026-07-13 12:15:00+00',90),
('sale_d04','buyer_delta','2026-07-14 13:15:00+00',155),
('sale_e05','buyer_ember','2026-07-15 14:15:00+00',60),
('sale_f06','buyer_fjord','2026-07-11 15:15:00+00',130),
('sale_g07','buyer_grove','2026-07-12 16:15:00+00',100),
('sale_h08','buyer_harbor','2026-07-13 10:15:00+00',170),
('sale_i09','buyer_indigo','2026-07-14 11:15:00+00',145),
('sale_j10','buyer_juniper','2026-07-15 12:15:00+00',85),
('sale_k11','buyer_kestrel','2026-07-11 13:15:00+00',140),
('sale_l12','buyer_lotus','2026-07-12 14:15:00+00',160),
('sale_after_close','buyer_birch','2026-07-17 00:05:00+00',40),
('sale_late_archive','buyer_fjord','2026-07-18 13:00:00+00',55),
('sale_unassigned','buyer_mistral','2026-07-12 12:00:00+00',99),
('sale_before_open','buyer_delta','2026-07-09 20:00:00+00',35);
