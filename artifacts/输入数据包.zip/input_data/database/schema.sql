CREATE TABLE assignments (
  user_id text PRIMARY KEY,
  platform text NOT NULL,
  market text NOT NULL,
  variant text NOT NULL CHECK (variant IN ('control','treatment')),
  assigned_at timestamptz NOT NULL
);

CREATE TABLE pre_period_metrics (
  user_id text PRIMARY KEY,
  pre_orders integer NOT NULL CHECK (pre_orders >= 0),
  pre_revenue numeric(12,2) NOT NULL CHECK (pre_revenue >= 0)
);

CREATE TABLE exposure_events (
  event_id text PRIMARY KEY,
  user_id text NOT NULL,
  experiment_id text NOT NULL,
  exposed_at timestamptz NOT NULL,
  surface text NOT NULL
);

CREATE TABLE orders (
  order_id text PRIMARY KEY,
  user_id text NOT NULL,
  paid_at timestamptz NOT NULL,
  revenue numeric(12,2) NOT NULL CHECK (revenue >= 0)
);
