CREATE TABLE analysis_policy (
  experiment_id text PRIMARY KEY,
  analysis_start_utc timestamptz NOT NULL,
  analysis_end_utc timestamptz NOT NULL,
  cuped_theta numeric NOT NULL,
  balance_watch_abs_delta_max integer NOT NULL CHECK (balance_watch_abs_delta_max >= 0),
  CHECK (analysis_end_utc > analysis_start_utc)
);

INSERT INTO analysis_policy VALUES
('checkout_refresh_2026_07','2026-07-10T00:00:00Z','2026-07-17T00:00:00Z',0.4,1);

CREATE TABLE quality_handling (
  flag_type text PRIMARY KEY,
  handling text NOT NULL
);

INSERT INTO quality_handling VALUES
('pre_assignment_exposure','exclude_exposure_and_review_user'),
('cross_experiment_exposure','ignore_other_experiment'),
('metric_outside_window','exclude_from_revenue'),
('unassigned_checkout_activity','exclude_missing_assignment');
