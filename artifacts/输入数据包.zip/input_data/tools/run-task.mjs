import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import pg from 'pg';

const {Client}=pg;
const inputRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const packageRoot=path.resolve(inputRoot,'..');
const outputRoot=path.join(packageRoot,'output');
const stageRoot=path.join(packageRoot,'.checkout_stage');
const required={
  schema:path.join(inputRoot,'database','schema.sql'),
  snapshot:path.join(inputRoot,'database','checkout_experiment_snapshot.sql'),
  policy:path.join(inputRoot,'rules','analysis_policy.sql'),
  candidate:path.join(inputRoot,'starter','analyze_checkout_experiment.sql'),
  client:path.join(inputRoot,'node_modules','pg','package.json'),
};
function assert(value,message){if(!value)throw new Error(message);}
function quoteIdentifier(value){return `"${String(value).replaceAll('"','""')}"`;}
function csvCell(value){const text=value===null||value===undefined?'':String(value);return /[",\r\n]/u.test(text)?`"${text.replaceAll('"','""')}"`:text;}
async function writeCsv(file,columns,rows){const lines=[columns.join(','),...rows.map(row=>columns.map(column=>csvCell(row[column])).join(','))];await fs.writeFile(file,`${lines.join('\n')}\n`,'utf8');}
async function openRuntime(){const connectionString=process.env.ALE_PG_URL;assert(connectionString,'缺少ALE_PG_URL');const adminUrl=new URL(connectionString);assert(['postgres:','postgresql:'].includes(adminUrl.protocol),'ALE_PG_URL协议错误');const admin=new Client({connectionString:adminUrl.toString(),connectionTimeoutMillis:5000});await admin.connect();const versionNumber=Number((await admin.query('SHOW server_version_num')).rows[0].server_version_num);assert(Math.floor(versionNumber/10000)>=17,`需要PostgreSQL17或更高兼容版本,实际版本:${versionNumber}`);const schemaName=`ale_checkout_${process.pid}_${crypto.randomBytes(4).toString('hex')}`;await admin.query(`CREATE SCHEMA ${quoteIdentifier(schemaName)}`);await admin.query(`SET search_path TO ${quoteIdentifier(schemaName)}, public`);return{admin,schemaName,versionNumber};}
async function closeRuntime(runtime){if(!runtime)return;try{await runtime.admin.query(`DROP SCHEMA IF EXISTS ${quoteIdentifier(runtime.schemaName)} CASCADE`);}finally{await runtime.admin.end();}}
async function main(){await fs.rm(outputRoot,{recursive:true,force:true});await fs.rm(stageRoot,{recursive:true,force:true});let runtime;try{for(const[name,file]of Object.entries(required)){const stat=await fs.stat(file).catch(()=>null);assert(stat?.isFile(),`缺少必需文件:${name}`);}const[schemaSql,snapshotSql,policySql,candidateSql]=await Promise.all([fs.readFile(required.schema,'utf8'),fs.readFile(required.snapshot,'utf8'),fs.readFile(required.policy,'utf8'),fs.readFile(required.candidate,'utf8')]);for(const name of['randomization_balance','analysis_orders','cuped_user_metric','cuped_revenue_by_variant','data_quality_flags'])assert(candidateSql.includes(name),`完成SQL缺少关系对象:${name}`);runtime=await openRuntime();const db=runtime.admin;for(const sql of[schemaSql,snapshotSql,policySql,candidateSql])await db.query(sql);const reports=[{name:'randomization_balance.csv',view:'randomization_balance',columns:['platform','market','control_users','treatment_users','total_users','abs_delta','status'],order:'platform,market'},{name:'cuped_revenue_by_variant.csv',view:'cuped_revenue_by_variant',columns:['variant','users','raw_revenue','avg_raw_revenue','cuped_revenue','avg_cuped_revenue'],order:'variant'},{name:'data_quality_flags.csv',view:'data_quality_flags',columns:['flag_type','affected_rows','affected_users','handling'],order:'flag_type'}];await fs.mkdir(path.join(stageRoot,'sql'),{recursive:true});await fs.mkdir(path.join(stageRoot,'reports'),{recursive:true});await fs.writeFile(path.join(stageRoot,'sql','analyze_checkout_experiment.sql'),candidateSql,'utf8');for(const report of reports){const rows=(await db.query(`SELECT ${report.columns.map(quoteIdentifier).join(',')} FROM ${quoteIdentifier(report.view)} ORDER BY ${report.order}`)).rows;await writeCsv(path.join(stageRoot,'reports',report.name),report.columns,rows);}await fs.rename(stageRoot,outputRoot);console.log(`实验评审报告已生成:PostgreSQL${runtime.versionNumber}`);}finally{await closeRuntime(runtime);}}
main().catch(async error=>{await fs.rm(stageRoot,{recursive:true,force:true});await fs.rm(outputRoot,{recursive:true,force:true});console.error(error.message);process.exitCode=2;});
