# 结账实验评审输入

database/schema.sql定义四张业务表。database/checkout_experiment_snapshot.sql保存脱敏后的实验分配、前置指标、曝光和订单。rules/analysis_policy.sql给出评审口径与质量问题处置。三份文件都必须由PostgreSQL Client执行。

把完成的SQL保存为同级output/sql/analyze_checkout_experiment.sql。在压缩包解压目录运行：

npm run process

连接串从环境变量ALE_PG_URL读取。入口在独立schema中装载输入并生成报告，结果写入output/reports。
